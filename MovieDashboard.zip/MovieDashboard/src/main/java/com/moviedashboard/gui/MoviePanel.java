package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.service.MovieService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MoviePanel extends JPanel {
    private JButton homeButton;
    private JButton backButton;
    private MovieService movieService;
    private MainFrame mainFrame;
    private JPanel buttonPanel;

    private static final Dimension BUTTON_SIZE = new Dimension(150, 50);

    public MoviePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        movieService = new MovieService();
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Movie Listings", JLabel.CENTER);
        add(label, BorderLayout.NORTH);

        // Add navigation buttons
        JPanel navPanel = new JPanel();
        homeButton = new JButton("Home");
        backButton = new JButton("Back");

        homeButton.setPreferredSize(BUTTON_SIZE);
        backButton.setPreferredSize(BUTTON_SIZE);

        navPanel.add(homeButton);
        navPanel.add(backButton);
        add(navPanel, BorderLayout.SOUTH);

        homeButton.addActionListener(e -> mainFrame.showHomePage());
        backButton.addActionListener(e -> mainFrame.navigateBack());

        // Initialize movie buttons
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        loadMovieData(buttonPanel);

        add(new JScrollPane(buttonPanel), BorderLayout.CENTER);
    }

    public void loadMovies(List<Movie> movies) {
        buttonPanel.removeAll();
        try {
            for (Movie movie : movies) {
                JButton button = new JButton(movie.getTitle());
                button.setPreferredSize(BUTTON_SIZE);
                button.addActionListener(e -> mainFrame.showMoviePage(movie));
                buttonPanel.add(button);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        buttonPanel.revalidate();
        buttonPanel.repaint();
    }

    private void loadMovieData(JPanel buttonPanel) {
        try {
            List<Movie> movies = movieService.getAllMovies();
            for (Movie movie : movies) {
                JButton button = new JButton(movie.getTitle());
                button.setPreferredSize(BUTTON_SIZE);
                button.addActionListener(e -> mainFrame.showMoviePage(movie));
                buttonPanel.add(button);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
