package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.model.Cast;
import com.moviedashboard.model.Review;
import com.moviedashboard.service.MovieService;
import com.moviedashboard.service.CastService;
import com.moviedashboard.service.ReviewService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class MovieDetailsPanel extends JPanel {

    private JLabel titleLabel;
    private JTextArea plotTextArea;
    private JLabel directorLabel;
    private JLabel genreLabel;
    private JLabel releaseYearLabel;
    private JLabel ratingLabel;
    private JTextArea castTextArea;
    private JTextArea reviewsTextArea;

    private MovieService movieService;
    private CastService castService;
    private ReviewService reviewService;

    public MovieDetailsPanel() {
        movieService = new MovieService();
        castService = new CastService();
        reviewService = new ReviewService();

        setLayout(new BorderLayout(10, 10));

        // Header Panel for Title
        JPanel headerPanel = new JPanel(new BorderLayout());
        titleLabel = new JLabel("Title", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        // Center Panel for Plot and Details
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        // Plot Area
        plotTextArea = new JTextArea();
        plotTextArea.setWrapStyleWord(true);
        plotTextArea.setLineWrap(true);
        plotTextArea.setEditable(false);
        plotTextArea.setBorder(BorderFactory.createTitledBorder("Plot"));
        centerPanel.add(new JScrollPane(plotTextArea), BorderLayout.CENTER);

        // Details Panel (Director, Genre, Release Year, Rating)
        JPanel detailsPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        directorLabel = new JLabel("Director: ");
        genreLabel = new JLabel("Genre: ");
        releaseYearLabel = new JLabel("Release Year: ");
        ratingLabel = new JLabel("Rating: ");
        detailsPanel.add(directorLabel);
        detailsPanel.add(genreLabel);
        detailsPanel.add(releaseYearLabel);
        detailsPanel.add(ratingLabel);
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Details"));
        centerPanel.add(detailsPanel, BorderLayout.EAST);

        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel for Cast and Reviews
        JPanel bottomPanel = new JPanel(new GridLayout(1, 2, 10, 10));

        // Cast Area
        castTextArea = new JTextArea();
        castTextArea.setWrapStyleWord(true);
        castTextArea.setLineWrap(true);
        castTextArea.setEditable(false);
        castTextArea.setBorder(BorderFactory.createTitledBorder("Cast"));
        bottomPanel.add(new JScrollPane(castTextArea));

        // Reviews Area
        reviewsTextArea = new JTextArea();
        reviewsTextArea.setWrapStyleWord(true);
        reviewsTextArea.setLineWrap(true);
        reviewsTextArea.setEditable(false);
        reviewsTextArea.setBorder(BorderFactory.createTitledBorder("Reviews"));
        bottomPanel.add(new JScrollPane(reviewsTextArea));

        add(bottomPanel, BorderLayout.SOUTH);
    }

    public void displayMovieDetails(int movieId) {
        try {
            Movie movie = movieService.getMovieById(movieId);
            titleLabel.setText(movie.getTitle());
            plotTextArea.setText(movie.getPlot());
            directorLabel.setText("Director: " + movie.getDirector());
            genreLabel.setText("Genre: " + movie.getGenre());
            releaseYearLabel.setText("Release Year: " + movie.getReleaseYear());
            ratingLabel.setText("Rating: " + movie.getRating());

            List<Cast> castList = castService.getCastByMovieId(movieId);
            StringBuilder castStr = new StringBuilder();
            for (Cast cast : castList) {
                castStr.append(cast.getActorName()).append("\n");
            }
            castTextArea.setText(castStr.toString());

            List<Review> reviewList = reviewService.getReviewsByMovieId(movieId);
            StringBuilder reviewsStr = new StringBuilder();
            for (Review review : reviewList) {
                reviewsStr.append(review.getUserName()).append(" (").append(review.getRating()).append("): ").append(review.getReview()).append("\n");
            }
            reviewsTextArea.setText(reviewsStr.toString());

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
