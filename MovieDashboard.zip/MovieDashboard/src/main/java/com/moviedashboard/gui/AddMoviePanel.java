package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.model.Cast;
import com.moviedashboard.service.MovieService;
import com.moviedashboard.service.CastService;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AddMoviePanel extends JPanel {
    private JTextField titleField;
    private JTextField genreField;
    private JTextField directorField;
    private JTextField yearField;
    private JTextField ratingField;
    private JTextArea plotArea;
    private JPanel castPanel;
    private List<JTextField> castFields;
    private JButton addCastButton;
    private JButton removeCastButton;
    private JButton submitButton;
    private JButton homeButton;
    private JButton backButton;
    private MovieService movieService;
    private CastService castService;
    private MainFrame mainFrame;

    public AddMoviePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        movieService = new MovieService();
        castService = new CastService();
        castFields = new ArrayList<>();
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Add Movie", JLabel.CENTER);
        add(label, BorderLayout.NORTH);

        // Add navigation buttons
        JPanel navPanel = new JPanel();
        homeButton = new JButton("Home");
        backButton = new JButton("Back");
        navPanel.add(homeButton);
        navPanel.add(backButton);
        add(navPanel, BorderLayout.SOUTH);

        homeButton.addActionListener(e -> mainFrame.showHomePage());
        backButton.addActionListener(e -> mainFrame.navigateBack());

        JPanel formPanel = new JPanel(new GridLayout(6, 2));
        formPanel.add(new JLabel("Title:"));
        titleField = new JTextField();
        formPanel.add(titleField);

        formPanel.add(new JLabel("Genre:"));
        genreField = new JTextField();
        formPanel.add(genreField);

        formPanel.add(new JLabel("Director:"));
        directorField = new JTextField();
        formPanel.add(directorField);

        formPanel.add(new JLabel("Year:"));
        yearField = new JTextField();
        formPanel.add(yearField);

        formPanel.add(new JLabel("Rating:"));
        ratingField = new JTextField();
        formPanel.add(ratingField);

        formPanel.add(new JLabel("Plot:"));
        plotArea = new JTextArea(3, 20);
        formPanel.add(new JScrollPane(plotArea));

        add(formPanel, BorderLayout.CENTER);

        // Cast panel
        castPanel = new JPanel();
        castPanel.setLayout(new BoxLayout(castPanel, BoxLayout.Y_AXIS));
        addCastButton = new JButton("Add Cast");
        addCastButton.addActionListener(e -> addCastField());
        removeCastButton = new JButton("Remove Cast");
        removeCastButton.addActionListener(e -> removeCastField());

        JPanel castControlPanel = new JPanel();
        castControlPanel.add(addCastButton);
        castControlPanel.add(removeCastButton);

        JPanel castContainer = new JPanel(new BorderLayout());
        castContainer.add(new JLabel("Cast:"), BorderLayout.NORTH);
        castContainer.add(new JScrollPane(castPanel), BorderLayout.CENTER);
        castContainer.add(castControlPanel, BorderLayout.SOUTH);

        add(castContainer, BorderLayout.EAST);

        // Submit button
        submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> addMovie());
        add(submitButton, BorderLayout.SOUTH);
    }

    private void addCastField() {
        JTextField castField = new JTextField(20);
        castFields.add(castField);
        castPanel.add(castField);
        castPanel.revalidate();
        castPanel.repaint();
    }

    private void removeCastField() {
        if (!castFields.isEmpty()) {
            JTextField castField = castFields.remove(castFields.size() - 1);
            castPanel.remove(castField);
            castPanel.revalidate();
            castPanel.repaint();
        }
    }

    private void addMovie() {
        try {
            String title = titleField.getText();
            String genre = genreField.getText();
            String director = directorField.getText();
            int year = Integer.parseInt(yearField.getText());
            double rating = Double.parseDouble(ratingField.getText());
            String plot = plotArea.getText();

            Movie movie = new Movie(0, title, genre, director, plot, year, rating); // Assuming ID is auto-generated
            int movieId = movieService.addMovie(movie);

            for (JTextField castField : castFields) {
                String actorName = castField.getText();
                if (!actorName.isEmpty()) {
                    Cast cast = new Cast(0, movieId, actorName); // Assuming ID is auto-generated
                    castService.addCast(cast);
                }
            }

            JOptionPane.showMessageDialog(this, "Movie and cast added successfully!");
            mainFrame.showHomePage(); // Navigate back to home page
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding movie or cast. Please try again.");
        }
    }
}
