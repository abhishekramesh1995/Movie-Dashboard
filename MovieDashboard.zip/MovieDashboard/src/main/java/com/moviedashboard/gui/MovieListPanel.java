package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.service.MovieService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MovieListPanel extends JPanel {
    private JList<Movie> movieList;
    private static DefaultListModel<Movie> listModel;
    private static MovieService movieService;
    private MainFrame mainFrame;

    public MovieListPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        movieService = new MovieService();

        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Movies", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        movieList = new JList<>(listModel);
        movieList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        movieList.setVisibleRowCount(10);

        JScrollPane listScrollPane = new JScrollPane(movieList);
        add(listScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton viewMovieButton = new JButton("View Movie");
        viewMovieButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Movie selectedMovie = movieList.getSelectedValue();
                if (selectedMovie != null) {
                    mainFrame.showMoviePage(selectedMovie);
                }
            }
        });
        buttonPanel.add(viewMovieButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void updateMovieList() {
        try {
            listModel.clear();
            List<Movie> movies = movieService.getAllMovies();
            for (Movie movie : movies) {
                listModel.addElement(movie);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
