package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private MoviePanel moviePanel;
    private SearchPanel searchPanel;
    private ReviewPanel reviewPanel;
    private MoviePage moviePage;
    private AddMoviePanel addMoviePanel;

    public MainFrame() {
        setTitle("Movie Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize panels
        moviePanel = new MoviePanel(this);
        searchPanel = new SearchPanel(moviePanel);
        reviewPanel = new ReviewPanel(this);
        moviePage = new MoviePage(this);
        addMoviePanel = new AddMoviePanel(this);

        // Show home page initially
        showHomePage();

        // Set background color
        getContentPane().setBackground(Color.WHITE);

        // Set font
        Font defaultFont = new Font("Arial", Font.PLAIN, 14);
        setFont(defaultFont);
        UIManager.put("Button.font", defaultFont);
        UIManager.put("Label.font", defaultFont);
        UIManager.put("TextField.font", defaultFont);
        UIManager.put("TextArea.font", defaultFont);
    }

    public void showHomePage() {
        getContentPane().removeAll();
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        topPanel.setBackground(Color.LIGHT_GRAY);

        // Add search panel
        topPanel.add(searchPanel, BorderLayout.NORTH);

        // Add "Add Movie" button
        JButton addMovieButton = new JButton("Add Movie");
        addMovieButton.addActionListener(e -> showAddMoviePanel());
        topPanel.add(addMovieButton, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(moviePanel), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public void navigateBack() {
        // Navigate back to the previous page
    }

    public void showMoviePage(Movie movie) {
        moviePage.displayMovieDetails(movie);
        getContentPane().removeAll();
        setLayout(new BorderLayout());
        add(moviePage, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public void showReviewPanel(Movie movie) {
        reviewPanel.setMovie(movie);
        getContentPane().removeAll();
        setLayout(new BorderLayout());
        add(reviewPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public void showAddMoviePanel() {
        getContentPane().removeAll();
        setLayout(new BorderLayout());
        add(addMoviePanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        });
    }

    public void showUpdateMoviePanel(Movie movie) {
        getContentPane().removeAll();
        setLayout(new BorderLayout());

        UpdateMoviePanel updateMoviePanel = new UpdateMoviePanel(this);
        updateMoviePanel.setMovieDetails(movie);

        add(updateMoviePanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }
}
