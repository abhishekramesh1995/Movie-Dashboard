package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.service.MovieService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class SearchPanel extends JPanel {

    private JTextField titleField;
    private JTextField genreField;
    private MoviePanel moviePanel;
    private MovieService movieService;
    private JTextField directorField; // Declare directorField here
    private JButton addMovieButton;

    public SearchPanel(MoviePanel moviePanel) {
        addMovieButton = new JButton("Add Movie");
        this.moviePanel = moviePanel;
        this.movieService = new MovieService();

        setLayout(new FlowLayout());

        JLabel titleLabel = new JLabel("Title:");
        titleField = new JTextField(10);

        JLabel genreLabel = new JLabel("Genre:");
        genreField = new JTextField(10);

        JLabel directorLabel = new JLabel("Director:"); // Add director label
        directorField = new JTextField(10); // Initialize directorField

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchMovies();
            }
        });

        add(titleLabel);
        add(titleField);
        add(genreLabel);
        add(genreField);
        add(directorLabel); // Add director label
        add(directorField); // Add director field
        add(searchButton);
    }

    private void searchMovies() {
        try {
            String title = titleField.getText();
            String genre = genreField.getText();
            String director = directorField.getText();

            // Retrieve all movies from the database and apply filtering locally
            List<Movie> allMovies = movieService.getAllMovies(); // Assuming a method to fetch all movies
            List<Movie> filteredMovies = new ArrayList<>();

            // Apply filtering based on the search criteria
            for (Movie movie : allMovies) {
                if (movie.getTitle().toLowerCase().contains(title.toLowerCase()) &&
                        movie.getGenre().toLowerCase().contains(genre.toLowerCase()) &&
                        movie.getDirector().toLowerCase().contains(director.toLowerCase())) {
                    filteredMovies.add(movie);
                }
            }

            // Update the movie panel with the filtered results
            moviePanel.loadMovies(filteredMovies);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
