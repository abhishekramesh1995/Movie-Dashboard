package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.service.MovieService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UpdateMoviePanel extends JPanel {
    private JTextField titleField;
    private JTextArea plotTextArea;
    private JTextField directorField;
    private JTextField genreField;
    private JTextField releaseYearField;
    private JTextField ratingField;
    private JButton updateButton;
    private JButton backButton;

    private MovieService movieService;
    private Movie currentMovie;
    private MainFrame mainFrame;

    public UpdateMoviePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        movieService = new MovieService();

        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        titleField = new JTextField(20);
        plotTextArea = new JTextArea(4, 20);
        directorField = new JTextField(20);
        genreField = new JTextField(20);
        releaseYearField = new JTextField(20);
        ratingField = new JTextField(20);

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Title: "), gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new JLabel("Plot: "), gbc);
        gbc.gridx = 1;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.BOTH;
        formPanel.add(new JScrollPane(plotTextArea), gbc);
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.NONE;

        gbc.gridx = 0;
        gbc.gridy += 2;
        formPanel.add(new JLabel("Director: "), gbc);
        gbc.gridx = 1;
        formPanel.add(directorField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new JLabel("Genre: "), gbc);
        gbc.gridx = 1;
        formPanel.add(genreField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new JLabel("Release Year: "), gbc);
        gbc.gridx = 1;
        formPanel.add(releaseYearField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        formPanel.add(new JLabel("Rating: "), gbc);
        gbc.gridx = 1;
        formPanel.add(ratingField, gbc);

        updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateMovieDetails();
            }
        });

        backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showMoviePage(currentMovie);
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(backButton);

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public void setMovieDetails(Movie movie) {
        this.currentMovie = movie;
        titleField.setText(movie.getTitle());
        plotTextArea.setText(movie.getPlot());
        directorField.setText(movie.getDirector());
        genreField.setText(movie.getGenre());
        releaseYearField.setText(String.valueOf(movie.getReleaseYear()));
        ratingField.setText(String.valueOf(movie.getRating()));
    }

    private void updateMovieDetails() {
        currentMovie.setTitle(titleField.getText());
        currentMovie.setPlot(plotTextArea.getText());
        currentMovie.setDirector(directorField.getText());
        currentMovie.setGenre(genreField.getText());
        currentMovie.setReleaseYear(Integer.parseInt(releaseYearField.getText()));
        currentMovie.setRating(Double.parseDouble(ratingField.getText()));

        try {
            movieService.updateMovie(currentMovie);
            mainFrame.showMoviePage(currentMovie);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to update movie details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
