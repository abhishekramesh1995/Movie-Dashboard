package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.model.Review;
import com.moviedashboard.service.ReviewService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReviewPanel extends JPanel {

    private static JTextField userField;
    private static JTextField ratingField;
    private static JTextArea reviewArea;
    private static ReviewService reviewService;
    private JButton submitButton; // Add submit button
    private JButton homeButton;
    private JButton backButton;
    private MainFrame mainFrame;
    private static Movie currentMovie;

    public ReviewPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        reviewService = new ReviewService();
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Add Review", JLabel.CENTER);
        add(label, BorderLayout.NORTH);

        JPanel reviewForm = new JPanel(new GridLayout(3, 2));
        JLabel userLabel = new JLabel("User:");
        userField = new JTextField();
        JLabel ratingLabel = new JLabel("Rating:");
        ratingField = new JTextField();
        JLabel reviewLabel = new JLabel("Review:");
        reviewArea = new JTextArea(3, 20);

        reviewForm.add(userLabel);
        reviewForm.add(userField);
        reviewForm.add(ratingLabel);
        reviewForm.add(ratingField);
        reviewForm.add(reviewLabel);
        reviewForm.add(new JScrollPane(reviewArea));

        add(reviewForm, BorderLayout.CENTER);

        // Add submit button
        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitReview();
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(submitButton); // Add submit button to buttonPanel
        add(buttonPanel, BorderLayout.SOUTH); // Add buttonPanel to the SOUTH of the ReviewPanel

        // Add navigation buttons
        JPanel navPanel = new JPanel();
        homeButton = new JButton("Home");
        backButton = new JButton("Back");
        submitButton = new JButton("Submit");
        navPanel.add(homeButton);
        navPanel.add(backButton);
        navPanel.add(submitButton);
        add(navPanel, BorderLayout.SOUTH);

        homeButton.addActionListener(e -> mainFrame.showHomePage());
        backButton.addActionListener(e -> mainFrame.navigateBack());
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitReview();
            }
        });

    }

    public void setMovie(Movie movie) {
        this.currentMovie = movie;
    }

    private void submitReview() {
        try {
            String user = userField.getText();
            double rating = Double.parseDouble(ratingField.getText());
            String reviewText = reviewArea.getText();

            Review review = new Review(0, currentMovie.getId(), user, rating, reviewText);
            reviewService.addReview(review);
            JOptionPane.showMessageDialog(ReviewPanel.this, "Review submitted successfully!");

            clearReviewFields();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error submitting review. Please try again.");
        }
    }

    private static void clearReviewFields() {
        userField.setText("");
        ratingField.setText("");
        reviewArea.setText("");
    }
}
