package com.moviedashboard.gui;

import com.moviedashboard.model.Movie;
import com.moviedashboard.service.MovieService;
import com.moviedashboard.service.CastService;
import com.moviedashboard.service.ReviewService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class MoviePage extends JPanel {
    private static JLabel titleLabel;
    private static JTextArea plotTextArea;
    private JLabel directorLabel;
    private static JLabel genreLabel;
    private static JLabel releaseYearLabel;
    private static JLabel ratingLabel;
    private static JTextArea castTextArea;
    private static JTextArea reviewsTextArea;
    private JButton addReviewButton;
    private JButton updateMovieButton;
    private JButton homeButton;
    private JButton backButton;
    private JButton deleteMovieButton;

    private MovieService movieService;
    private static CastService castService;
    private static ReviewService reviewService;
    private MainFrame mainFrame;
    private Movie currentMovie;

    public MoviePage(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        movieService = new MovieService();
        castService = new CastService();
        reviewService = new ReviewService();

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.LIGHT_GRAY);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        titleLabel = new JLabel("Title", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        JPanel navPanel = new JPanel();
        navPanel.setOpaque(false);
        homeButton = new JButton("Home");
        backButton = new JButton("Back");
        navPanel.add(homeButton);
        navPanel.add(backButton);
        topPanel.add(navPanel, BorderLayout.EAST);

        homeButton.addActionListener(e -> mainFrame.showHomePage());
        backButton.addActionListener(e -> mainFrame.navigateBack());

        add(topPanel, BorderLayout.NORTH);

        JPanel detailsPanel = new JPanel(new GridBagLayout());
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        detailsPanel.setBackground(Color.WHITE);

        directorLabel = new JLabel("Director: ");
        genreLabel = new JLabel("Genre: ");
        releaseYearLabel = new JLabel("Release Year: ");
        ratingLabel = new JLabel("Rating: ");

        gbc.gridx = 0;
        gbc.gridy = 0;
        detailsPanel.add(directorLabel, gbc);

        gbc.gridy++;
        detailsPanel.add(genreLabel, gbc);

        gbc.gridy++;
        detailsPanel.add(releaseYearLabel, gbc);

        gbc.gridy++;
        detailsPanel.add(ratingLabel, gbc);

        plotTextArea = new JTextArea(4, 30);
        plotTextArea.setWrapStyleWord(true);
        plotTextArea.setLineWrap(true);
        plotTextArea.setEditable(false);
        plotTextArea.setBorder(BorderFactory.createTitledBorder("Plot"));

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        detailsPanel.add(new JScrollPane(plotTextArea), gbc);

        castTextArea = new JTextArea(4, 30);
        castTextArea.setWrapStyleWord(true);
        castTextArea.setLineWrap(true);
        castTextArea.setEditable(false);
        castTextArea.setBorder(BorderFactory.createTitledBorder("Cast"));

        gbc.gridy++;
        detailsPanel.add(new JScrollPane(castTextArea), gbc);

        reviewsTextArea = new JTextArea(4, 30);
        reviewsTextArea.setWrapStyleWord(true);
        reviewsTextArea.setLineWrap(true);
        reviewsTextArea.setEditable(false);
        reviewsTextArea.setBorder(BorderFactory.createTitledBorder("Reviews"));

        gbc.gridy++;
        detailsPanel.add(new JScrollPane(reviewsTextArea), gbc);

        add(detailsPanel, BorderLayout.CENTER);

        addReviewButton = new JButton("Add Review");
        addReviewButton.setBackground(new Color(220, 220, 220));
        addReviewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showReviewPanel(currentMovie);
            }
        });
        updateMovieButton = new JButton("Update Movie");
        updateMovieButton.setBackground(new Color(220, 220, 220));
        updateMovieButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showUpdateMoviePanel(currentMovie);
            }
        });
        deleteMovieButton = new JButton("Delete Movie");
        deleteMovieButton.setBackground(new Color(220, 220, 220));
        deleteMovieButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteCurrentMovie();
            }
        });
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(addReviewButton);
        buttonPanel.add(updateMovieButton);
        buttonPanel.add(deleteMovieButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public void displayMovieDetails(Movie movie) {
        this.currentMovie = movie;
        try {
            titleLabel.setText(movie.getTitle());
            plotTextArea.setText(movie.getPlot());
            directorLabel.setText("Director: " + movie.getDirector());
            genreLabel.setText("Genre: " + movie.getGenre());
            releaseYearLabel.setText("Release Year: " + movie.getReleaseYear());
            ratingLabel.setText("Rating: " + movie.getRating());

            List<com.moviedashboard.model.Cast> castList = castService.getCastByMovieId(movie.getId());
            StringBuilder castStr = new StringBuilder();
            for (com.moviedashboard.model.Cast cast : castList) {
                castStr.append(cast.getActorName()).append("\n");
            }
            castTextArea.setText(castStr.toString());

            List<com.moviedashboard.model.Review> reviewList = reviewService.getReviewsByMovieId(movie.getId());
            StringBuilder reviewsStr = new StringBuilder();
            for (com.moviedashboard.model.Review review : reviewList) {
                reviewsStr.append(review.getUserName()).append(" (").append(review.getRating()).append("): ").append(review.getReview()).append("\n");
            }
            reviewsTextArea.setText(reviewsStr.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteCurrentMovie() {
        if (currentMovie != null) {
            try {
                movieService.deleteMovie(currentMovie);
                mainFrame.showHomePage();
                displayMovieDetails(new Movie());
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Failed to delete movie.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No movie selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
