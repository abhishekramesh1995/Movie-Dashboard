package com.moviedashboard.model;

public class Cast {
    private int id;
    private int movieId;
    private String actorName;

    public Cast(int id, int movieId, String actorName) {
        this.id = id;
        this.movieId = movieId;
        this.actorName = actorName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    @Override
    public String toString() {
        return "Cast{" +
                "id=" + id +
                ", movieId=" + movieId +
                ", actorName='" + actorName + '\'' +
                '}';
    }
}
