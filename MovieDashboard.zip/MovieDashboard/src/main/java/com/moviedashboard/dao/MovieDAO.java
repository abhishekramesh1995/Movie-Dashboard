package com.moviedashboard.dao;

import com.moviedashboard.model.Movie;
import com.moviedashboard.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class
MovieDAO {
    private static final String INSERT_MOVIE_SQL = "INSERT INTO movies (title, genre, director, plot, release_year, rating) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_MOVIE_SQL = "UPDATE movies SET title = ?, genre = ?, director = ?, plot = ?, release_year = ?, rating = ? WHERE id = ?";

    public int addMovie(Movie movie) throws SQLException {
        int movieId = 0;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MOVIE_SQL, PreparedStatement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, movie.getTitle());
            preparedStatement.setString(2, movie.getGenre());
            preparedStatement.setString(3, movie.getDirector());
            preparedStatement.setString(4, movie.getPlot());
            preparedStatement.setInt(5, movie.getReleaseYear());
            preparedStatement.setDouble(6, movie.getRating());

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        movieId = generatedKeys.getInt(1);
                    }
                }
            }
        }
        return movieId;
    }

    public void updateMovie(Movie movie) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_MOVIE_SQL)) {
            preparedStatement.setString(1, movie.getTitle());
            preparedStatement.setString(2, movie.getGenre());
            preparedStatement.setString(3, movie.getDirector());
            preparedStatement.setString(4, movie.getPlot());
            preparedStatement.setInt(5, movie.getReleaseYear());
            preparedStatement.setDouble(6, movie.getRating());
            preparedStatement.setInt(7, movie.getId());

            preparedStatement.executeUpdate();
        }
    }



    // Retrieves a movie by its ID
    public Movie getMovieById(int id) throws SQLException {
        String query = "SELECT * FROM Movies WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getString("director"),
                            rs.getString("plot"),
                            rs.getInt("release_year"),
                            rs.getDouble("rating")  // Retrieve as double directly
                    );
                }
            }
        }
        return null;
    }

    // Retrieves a list of all movies
    public List<Movie> getAllMovies() throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String query = "SELECT * FROM Movies";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                movies.add(new Movie(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getString("director"),
                        rs.getString("plot"),
                        rs.getInt("release_year"),
                        rs.getDouble("rating")  // Retrieve as double directly
                ));
            }
        }
        return movies;
    }

    // Updates the information of an existing movie


    // Deletes a movie by its ID
    public void deleteMovie(int id) throws SQLException {
        String query = "DELETE FROM Movies WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    // Searches for movies by title
    public List<Movie> searchMoviesByTitle(String title) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String query = "SELECT * FROM Movies WHERE title LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + title + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getString("director"),
                            rs.getString("plot"),
                            rs.getInt("release_year"),
                            rs.getDouble("rating")  // Retrieve as double directly
                    ));
                }
            }
        }
        return movies;
    }

    // Searches for movies by genre
    public List<Movie> searchMoviesByGenre(String genre) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String query = "SELECT * FROM Movies WHERE genre LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + genre + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getString("director"),
                            rs.getString("plot"),
                            rs.getInt("release_year"),
                            rs.getDouble("rating")  // Retrieve as double directly
                    ));
                }
            }
        }
        return movies;
    }

    // Searches for movies by actor name
    public List<Movie> searchMoviesByActor(String actorName) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String query = "SELECT m.* FROM Movies m JOIN Cast c ON m.id = c.movie_id WHERE c.actor_name LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + actorName + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getString("director"),
                            rs.getString("plot"),
                            rs.getInt("release_year"),
                            rs.getDouble("rating")  // Retrieve as double directly
                    ));
                }
            }
        }
        return movies;
    }

    // Filters movies based on various criteria
    public List<Movie> filterMovies(String title, String genre, String actorName) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String query = "SELECT DISTINCT m.* FROM Movies m " +
                "LEFT JOIN Cast c ON m.id = c.movie_id " +
                "WHERE m.title LIKE ? AND m.genre LIKE ? AND c.actor_name LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + title + "%");
            stmt.setString(2, "%" + genre + "%");
            stmt.setString(3, "%" + actorName + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getString("director"),
                            rs.getString("plot"),
                            rs.getInt("release_year"),
                            rs.getDouble("rating")  // Retrieve as double directly
                    ));
                }
            }
        }
        return movies;
    }
}
