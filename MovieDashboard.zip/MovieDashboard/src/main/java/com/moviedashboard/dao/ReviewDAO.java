package com.moviedashboard.dao;

import com.moviedashboard.model.Review;
import com.moviedashboard.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReviewDAO {

    // Adds a new review to the database
    public void addReview(Review review) throws SQLException {
        String query = "INSERT INTO Reviews (movie_id, user_name, rating, review) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, review.getMovieId());
            stmt.setString(2, review.getUserName());
            stmt.setDouble(3, review.getRating());
            stmt.setString(4, review.getReview());
            stmt.executeUpdate();
        }
    }

    // Retrieves a review by its ID
    public Review getReviewById(int id) throws SQLException {
        String query = "SELECT * FROM Reviews WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Review(
                            rs.getInt("id"),
                            rs.getInt("movie_id"),
                            rs.getString("user_name"),
                            rs.getDouble("rating"),
                            rs.getString("review")
                    );
                }
            }
        }
        return null;
    }

    // Retrieves all reviews for a specific movie
    public List<Review> getReviewsByMovieId(int movieId) throws SQLException {
        List<Review> reviews = new ArrayList<>();
        String query = "SELECT * FROM Reviews WHERE movie_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, movieId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reviews.add(new Review(
                            rs.getInt("id"),
                            rs.getInt("movie_id"),
                            rs.getString("user_name"),
                            rs.getDouble("rating"),
                            rs.getString("review")
                    ));
                }
            }
        }
        return reviews;
    }

    // Updates an existing review
    public void updateReview(Review review) throws SQLException {
        String query = "UPDATE Reviews SET movie_id = ?, user_name = ?, rating = ?, review = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, review.getMovieId());
            stmt.setString(2, review.getUserName());
            stmt.setDouble(3, review.getRating());
            stmt.setString(4, review.getReview());
            stmt.setInt(5, review.getId());
            stmt.executeUpdate();
        }
    }

    // Deletes a review by its ID
    public void deleteReview(int id) throws SQLException {
        String query = "DELETE FROM Reviews WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
