package com.moviedashboard.dao;

import com.moviedashboard.model.Cast;
import com.moviedashboard.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CastDAO {

    private static final String INSERT_CAST_SQL = "INSERT INTO cast (movie_id, actor_name) VALUES (?, ?)";
    private static final String DELETE_CAST_SQL = "DELETE FROM cast WHERE id = ?";

    public void addCast(Cast cast) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CAST_SQL)) {
            preparedStatement.setInt(1, cast.getMovieId());
            preparedStatement.setString(2, cast.getActorName());

            preparedStatement.executeUpdate();
        }
    }

    public void deleteCast(Cast cast) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CAST_SQL)) {
            preparedStatement.setInt(1, cast.getId());

            preparedStatement.executeUpdate();
        }
    }


    // Retrieves cast members by movie ID
    public List<Cast> getCastByMovieId(int movieId) throws SQLException {
        List<Cast> castList = new ArrayList<>();
        String query = "SELECT * FROM Cast WHERE movie_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, movieId);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Cast cast = new Cast(
                            rs.getInt("id"),
                            rs.getInt("movie_id"),
                            rs.getString("actor_name")
                    );
                    castList.add(cast);
                }
            }
        }
        return castList;
    }

    // Updates an existing cast entry
    public void updateCast(Cast cast) throws SQLException {
        String query = "UPDATE Cast SET actor_name = ? WHERE id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, cast.getActorName());
            pst.setInt(2, cast.getId());
            pst.executeUpdate();
        }
    }

    // Deletes a cast entry by its ID
    public void deleteCast(int id) throws SQLException {
        String query = "DELETE FROM Cast WHERE id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, id);
            pst.executeUpdate();
        }
    }
}
