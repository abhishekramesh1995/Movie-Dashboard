package com.moviedashboard.main;

import javax.swing.SwingUtilities;
import com.moviedashboard.gui.MainFrame;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainFrame();
            }
        });
    }
}
