package com.moviedashboard.service;

import com.moviedashboard.dao.MovieDAO;
import com.moviedashboard.model.Movie;

import java.sql.SQLException;
import java.util.List;

public class MovieService {

    private MovieDAO movieDAO;



    public int addMovie(Movie movie) throws Exception {
        return movieDAO.addMovie(movie);
    }

    public void updateMovie(Movie movie) throws Exception {
        movieDAO.updateMovie(movie);
    }



    public Movie getMovieById(int id) throws SQLException {
        return movieDAO.getMovieById(id);
    }

    public List<Movie> getAllMovies() throws SQLException {
        return movieDAO.getAllMovies();
    }



    public MovieService() {
        this.movieDAO = new MovieDAO(); // Initialize your MovieDAO
    }

    public List<Movie> searchMoviesByTitle(String title) throws SQLException {
        return movieDAO.searchMoviesByTitle(title);
    }

    public List<Movie> searchMoviesByGenre(String genre) throws SQLException {
        return movieDAO.searchMoviesByGenre(genre);
    }

    public List<Movie> searchMoviesByActor(String actorName) throws SQLException {
        return movieDAO.searchMoviesByActor(actorName);
    }

    public List<Movie> filterMovies(String title, String genre, String actorName) throws SQLException {
        return movieDAO.filterMovies(title, genre, actorName);
    }

    public void deleteMovie(Movie movie) throws SQLException {
        movieDAO.deleteMovie(movie.getId()); // Assuming you have a deleteMovie method in your MovieDAO that accepts a movie ID
    }
}
