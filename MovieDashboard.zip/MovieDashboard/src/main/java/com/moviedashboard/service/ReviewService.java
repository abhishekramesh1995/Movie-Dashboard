package com.moviedashboard.service;

import com.moviedashboard.dao.ReviewDAO;
import com.moviedashboard.model.Review;

import java.sql.SQLException;
import java.util.List;

public class ReviewService {

    private ReviewDAO reviewDAO;

    public ReviewService() {
        this.reviewDAO = new ReviewDAO();
    }

    public void addReview(Review review) throws Exception {
        reviewDAO.addReview(review);
    }
    // Retrieves a review by its ID
    public Review getReviewById(int id) throws SQLException {
        return reviewDAO.getReviewById(id);
    }

    // Retrieves all reviews for a specific movie
    public List<Review> getReviewsByMovieId(int movieId) throws SQLException {
        return reviewDAO.getReviewsByMovieId(movieId);
    }

    // Updates an existing review
    public void updateReview(Review review) throws SQLException {
        reviewDAO.updateReview(review);
    }

    // Deletes a review by its ID
    public void deleteReview(int id) throws SQLException {
        reviewDAO.deleteReview(id);
    }
}
