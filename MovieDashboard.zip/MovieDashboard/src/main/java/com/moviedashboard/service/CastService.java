package com.moviedashboard.service;

import com.moviedashboard.dao.CastDAO;
import com.moviedashboard.model.Cast;

import java.sql.SQLException;
import java.util.List;

public class CastService {
    private CastDAO castDAO;


    public CastService() {
        castDAO = new CastDAO();
    }

    public void addCast(Cast cast) throws Exception {
        castDAO.addCast(cast);
    }

    public void deleteCast(Cast cast) throws Exception {
        castDAO.deleteCast(cast);
    }

    public List<Cast> getCastByMovieId(int movieId) throws Exception {
        return castDAO.getCastByMovieId(movieId);
    }


    // Updates an existing cast member
    public void updateCast(Cast cast) throws SQLException {
        castDAO.updateCast(cast);
    }

    // Deletes a cast member by its ID
    public void deleteCast(int id) throws SQLException {
        castDAO.deleteCast(id);
    }
}
